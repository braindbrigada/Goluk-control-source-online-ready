package com.stepmat.golukcontrol.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Форматирование размера в человекочитаемый вид.
 */
fun formatBytes(bytes: Long?): String {
    if (bytes == null || bytes <= 0L) return "—"
    val kb = 1024.0
    val mb = kb * 1024.0
    val gb = mb * 1024.0
    return when {
        bytes >= gb -> String.format(Locale.US, "%.2f ГБ", bytes / gb)
        bytes >= mb -> String.format(Locale.US, "%.2f МБ", bytes / mb)
        bytes >= kb -> String.format(Locale.US, "%.1f КБ", bytes / kb)
        else -> "$bytes Б"
    }
}

/**
 * Форматирование длительности ролика.
 */
fun formatDuration(seconds: Int?): String {
    if (seconds == null || seconds < 0) return "—"
    val minutes = seconds / 60
    val remain = seconds % 60
    return "%02d:%02d".format(minutes, remain)
}

/**
 * Форматирование unix-времени устройства.
 */
fun formatUnixTime(unixTime: Long?): String {
    if (unixTime == null || unixTime <= 0) return "—"
    val formatter = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault())
    return formatter.format(Date(unixTime * 1000L))
}
