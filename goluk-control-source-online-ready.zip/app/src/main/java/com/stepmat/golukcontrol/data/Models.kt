package com.stepmat.golukcontrol.data

/**
 * Универсальная модель ответа API с динамическими полями.
 */
data class DynamicApiResponse(
    val result: Int? = null,
    val msg: String? = null,
    val data: Map<String, Any?> = emptyMap(),
    val rawBody: String = ""
)

/**
 * Модель ролика регистратора.
 */
data class VideoItem(
    val id: String,
    val type: Int,
    val resolution: String? = null,
    val periodSeconds: Int? = null,
    val unixTime: Long? = null,
    val timestamp: String? = null,
    val sizeBytes: Long? = null,
    val location: String? = null,
    val withSnapshot: Boolean = false,
    val withThumb: Boolean = false,
    val withGps: Boolean = false
)

/**
 * Типы роликов, которые встречаются у Goluk T-series.
 */
enum class VideoType(val apiValue: Int, val title: String, val shortLabel: String) {
    REGULAR(1, "Обычные", "NRM"),
    PARKING(2, "Парковочные", "URG"),
    EVENT(4, "Сохранённые", "WND"),
    TIMELAPSE(5, "Таймлапс", "NRM_TL")
}

/**
 * Известные endpoint'ы API. Часть из них может работать по-разному в зависимости от прошивки.
 */
enum class KnownEndpoint(val path: String, val title: String, val hint: String) {
    SYSTEM_INFO("/api/systeminfo", "Информация об устройстве", "Без параметров"),
    SD_INFO("/api/sd", "Статус SD-карты", "Без параметров"),
    SD_FORMAT("/api/sdformat", "Форматирование SD-карты", "Без параметров"),
    SNAPSHOT("/api/snapshot", "Снимок", "Например id=0"),
    REBOOT("/api/reboot", "Перезагрузка", "Без параметров"),
    TIME("/api/time", "Время устройства", "Параметры зависят от прошивки"),
    CONF_HDR("/api/conf_hdr", "HDR", "Параметры зависят от прошивки"),
    CONF_VOICE("/api/conf_voice", "Озвучка / звук", "Параметры зависят от прошивки"),
    CONF_LOGO("/api/conf_logo", "Штамп / OSD", "Параметры зависят от прошивки"),
    CONF_STREAM("/api/conf_stream", "Поток / качество", "Параметры зависят от прошивки"),
    CONF_VOLUME("/api/conf_volume", "Громкость", "Параметры зависят от прошивки"),
    EVENT_RESOLUTION("/api/conf_event_resolution", "Разрешение", "Параметры зависят от прошивки"),
    EVENT_TIME("/api/conf_event_time", "Длительность события", "Параметры зависят от прошивки"),
    AUTO_FLIP("/api/auto_flip", "Автоповорот", "Параметры зависят от прошивки"),
    ADAS("/api/adas", "ADAS", "Параметры зависят от прошивки")
}

/**
 * Состояние отправки команды API.
 */
data class CommandResult(
    val endpoint: String = "",
    val requestUrl: String = "",
    val success: Boolean = false,
    val message: String = "",
    val rawBody: String = ""
)
