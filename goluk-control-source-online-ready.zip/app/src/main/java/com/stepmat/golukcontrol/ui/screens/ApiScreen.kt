package com.stepmat.golukcontrol.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Send
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.stepmat.golukcontrol.data.KnownEndpoint
import com.stepmat.golukcontrol.viewmodel.MainViewModel

@Composable
fun ApiScreen(
    paddingValues: PaddingValues,
    viewModel: MainViewModel
) {
    val state by viewModel.apiState.collectAsState()

    Column(
        modifier = ScreenColumnPadding(paddingValues)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Настройки / API",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Экран для отправки известных GET-команд в локальный API регистратора. Для части endpoint'ов параметры зависят от прошивки.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.secondary
        )

        SectionCard(
            title = "Быстрые команды",
            subtitle = "Безопасные запросы без догадок о скрытых параметрах"
        ) {
            PresetChipRow(
                labels = listOf(
                    "Перезагрузка" to { viewModel.sendQuickCommand(KnownEndpoint.REBOOT) },
                    "System info" to { viewModel.sendQuickCommand(KnownEndpoint.SYSTEM_INFO) },
                    "SD info" to { viewModel.sendQuickCommand(KnownEndpoint.SD_INFO) }
                )
            )
        }

        SectionCard(
            title = "Команда API",
            subtitle = "Можно выбрать endpoint и указать query-строку вручную"
        ) {
            EndpointDropdown(
                selected = state.selectedEndpoint,
                onSelected = viewModel::updateEndpoint
            )

            OutlinedTextField(
                value = state.rawQuery,
                onValueChange = viewModel::updateRawQuery,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Query параметры") },
                placeholder = { Text(state.selectedEndpoint.hint) },
                minLines = 2,
                supportingText = {
                    Text("Формат: key=value&key2=value2")
                }
            )

            Button(onClick = { viewModel.sendApiCommand() }) {
                Icon(Icons.Outlined.Send, contentDescription = null)
                Text("  Отправить")
            }

            if (state.isSending) {
                CircularProgressIndicator()
            }
            if (!state.error.isNullOrBlank()) {
                Text(text = state.error.orEmpty(), color = MaterialTheme.colorScheme.error)
            }
        }

        SectionCard(
            title = "Подсказки по расширению",
            subtitle = "Что логично добавить следующим этапом"
        ) {
            Text("• live preview по RTSP / pushstream")
            Text("• сохранение роликов в память телефона")
            Text("• типовые формы настроек для конкретной прошивки")
            Text("• сравнение текущих и желаемых параметров")
            Text("• отдельный просмотр snapshot / thumbnail как изображений")
        }

        state.lastResult?.let { result ->
            SectionCard(
                title = "Последний ответ",
                subtitle = result.requestUrl
            ) {
                Text(
                    text = if (result.success) "Успешно: ${result.message}" else "Ошибка: ${result.message}",
                    style = MaterialTheme.typography.titleSmall
                )
                OutlinedTextField(
                    value = result.rawBody.ifBlank { "Пустой ответ" },
                    onValueChange = {},
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 160.dp),
                    readOnly = true,
                    label = { Text("Raw response") }
                )
            }
        }
    }
}

@Composable
private fun EndpointDropdown(
    selected: KnownEndpoint,
    onSelected: (KnownEndpoint) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Column {
        OutlinedTextField(
            value = "${selected.title} (${selected.path})",
            onValueChange = {},
            modifier = Modifier.fillMaxWidth(),
            readOnly = true,
            label = { Text("Endpoint") }
        )
        Button(onClick = { expanded = true }) {
            Text("Выбрать endpoint")
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            KnownEndpoint.entries.forEach { endpoint ->
                DropdownMenuItem(
                    text = { Text("${endpoint.title} (${endpoint.path})") },
                    onClick = {
                        onSelected(endpoint)
                        expanded = false
                    }
                )
            }
        }
    }
}
