package com.stepmat.golukcontrol.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.stepmat.golukcontrol.data.CommandResult
import com.stepmat.golukcontrol.data.DynamicApiResponse
import com.stepmat.golukcontrol.data.GolukRepository
import com.stepmat.golukcontrol.data.KnownEndpoint
import com.stepmat.golukcontrol.data.VideoItem
import com.stepmat.golukcontrol.data.VideoType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val PREFS_NAME = "goluk_control_prefs"
private const val KEY_BASE_URL = "base_url"
private const val DEFAULT_BASE_URL = "http://192.168.62.1"

data class OverviewUiState(
    val baseUrl: String = DEFAULT_BASE_URL,
    val isCheckingConnection: Boolean = false,
    val isConnected: Boolean? = null,
    val isLoadingInfo: Boolean = false,
    val systemInfo: DynamicApiResponse? = null,
    val sdInfo: DynamicApiResponse? = null,
    val message: String? = null
)

data class VideosUiState(
    val selectedType: VideoType = VideoType.REGULAR,
    val isLoading: Boolean = false,
    val items: List<VideoItem> = emptyList(),
    val error: String? = null
)

data class ApiUiState(
    val selectedEndpoint: KnownEndpoint = KnownEndpoint.CONF_HDR,
    val rawQuery: String = "",
    val isSending: Boolean = false,
    val lastResult: CommandResult? = null,
    val error: String? = null
)

class MainViewModel(
    application: Application,
    private val repository: GolukRepository = GolukRepository()
) : ViewModel() {

    private val prefs = application.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _overviewState = MutableStateFlow(OverviewUiState(baseUrl = loadBaseUrl()))
    val overviewState: StateFlow<OverviewUiState> = _overviewState.asStateFlow()

    private val _videosState = MutableStateFlow(VideosUiState())
    val videosState: StateFlow<VideosUiState> = _videosState.asStateFlow()

    private val _apiState = MutableStateFlow(ApiUiState())
    val apiState: StateFlow<ApiUiState> = _apiState.asStateFlow()

    init {
        refreshOverview()
        loadVideos(VideoType.REGULAR)
    }

    fun updateBaseUrl(newValue: String) {
        _overviewState.value = _overviewState.value.copy(baseUrl = newValue)
    }

    fun persistBaseUrl() {
        val value = _overviewState.value.baseUrl.trim().ifBlank { DEFAULT_BASE_URL }
        prefs.edit().putString(KEY_BASE_URL, value).apply()
        _overviewState.value = _overviewState.value.copy(baseUrl = value)
    }

    fun checkConnection() {
        val baseUrl = _overviewState.value.baseUrl.trim().ifBlank { DEFAULT_BASE_URL }
        viewModelScope.launch {
            _overviewState.value = _overviewState.value.copy(isCheckingConnection = true, message = null)
            val isConnected = withContext(Dispatchers.IO) {
                repository.checkConnection(baseUrl)
            }
            _overviewState.value = _overviewState.value.copy(
                isCheckingConnection = false,
                isConnected = isConnected,
                message = if (isConnected) "Связь с регистратором есть" else "Регистратор не ответил"
            )
        }
    }

    fun refreshOverview() {
        val baseUrl = _overviewState.value.baseUrl.trim().ifBlank { DEFAULT_BASE_URL }
        persistBaseUrl()
        viewModelScope.launch {
            _overviewState.value = _overviewState.value.copy(isLoadingInfo = true, message = null)
            runCatching {
                withContext(Dispatchers.IO) {
                    val connected = repository.checkConnection(baseUrl)
                    val systemInfo = repository.fetchSystemInfo(baseUrl)
                    val sdInfo = repository.fetchSdStatus(baseUrl)
                    Triple(connected, systemInfo, sdInfo)
                }
            }.onSuccess { (connected, systemInfo, sdInfo) ->
                _overviewState.value = _overviewState.value.copy(
                    isLoadingInfo = false,
                    isConnected = connected,
                    systemInfo = systemInfo,
                    sdInfo = sdInfo,
                    message = "Данные обновлены"
                )
            }.onFailure { error ->
                _overviewState.value = _overviewState.value.copy(
                    isLoadingInfo = false,
                    isConnected = false,
                    message = error.message ?: "Не удалось получить данные"
                )
            }
        }
    }

    fun formatSdCard() {
        val baseUrl = _overviewState.value.baseUrl.trim().ifBlank { DEFAULT_BASE_URL }
        viewModelScope.launch {
            _overviewState.value = _overviewState.value.copy(isLoadingInfo = true, message = null)
            runCatching {
                withContext(Dispatchers.IO) {
                    repository.formatSdCard(baseUrl)
                }
            }.onSuccess { response ->
                _overviewState.value = _overviewState.value.copy(
                    isLoadingInfo = false,
                    message = response.msg ?: "Команда форматирования отправлена"
                )
                refreshOverview()
            }.onFailure { error ->
                _overviewState.value = _overviewState.value.copy(
                    isLoadingInfo = false,
                    message = error.message ?: "Не удалось отформатировать SD-карту"
                )
            }
        }
    }

    fun loadVideos(type: VideoType = _videosState.value.selectedType) {
        val baseUrl = _overviewState.value.baseUrl.trim().ifBlank { DEFAULT_BASE_URL }
        viewModelScope.launch {
            _videosState.value = _videosState.value.copy(selectedType = type, isLoading = true, error = null)
            runCatching {
                withContext(Dispatchers.IO) {
                    repository.fetchVideoList(baseUrl, type)
                }
            }.onSuccess { items ->
                _videosState.value = _videosState.value.copy(
                    selectedType = type,
                    isLoading = false,
                    items = items,
                    error = null
                )
            }.onFailure { error ->
                _videosState.value = _videosState.value.copy(
                    selectedType = type,
                    isLoading = false,
                    error = error.message ?: "Не удалось получить список роликов"
                )
            }
        }
    }

    fun buildVideoUrl(videoId: String): String {
        val baseUrl = _overviewState.value.baseUrl.trim().ifBlank { DEFAULT_BASE_URL }
        return repository.buildVideoUrl(baseUrl, videoId)
    }

    fun buildSnapshotUrl(): String {
        val baseUrl = _overviewState.value.baseUrl.trim().ifBlank { DEFAULT_BASE_URL }
        return repository.buildSnapshotUrl(baseUrl)
    }

    fun updateEndpoint(endpoint: KnownEndpoint) {
        _apiState.value = _apiState.value.copy(selectedEndpoint = endpoint)
    }

    fun updateRawQuery(value: String) {
        _apiState.value = _apiState.value.copy(rawQuery = value)
    }

    fun sendApiCommand() {
        val baseUrl = _overviewState.value.baseUrl.trim().ifBlank { DEFAULT_BASE_URL }
        val endpoint = _apiState.value.selectedEndpoint
        val rawQuery = _apiState.value.rawQuery

        viewModelScope.launch {
            _apiState.value = _apiState.value.copy(isSending = true, error = null)
            runCatching {
                withContext(Dispatchers.IO) {
                    repository.executeCommand(baseUrl, endpoint.path, rawQuery)
                }
            }.onSuccess { result ->
                _apiState.value = _apiState.value.copy(
                    isSending = false,
                    lastResult = result,
                    error = null
                )
            }.onFailure { error ->
                _apiState.value = _apiState.value.copy(
                    isSending = false,
                    error = error.message ?: "Не удалось отправить команду"
                )
            }
        }
    }

    fun sendQuickCommand(endpoint: KnownEndpoint, rawQuery: String = "") {
        updateEndpoint(endpoint)
        updateRawQuery(rawQuery)
        sendApiCommand()
    }

    private fun loadBaseUrl(): String {
        return prefs.getString(KEY_BASE_URL, DEFAULT_BASE_URL) ?: DEFAULT_BASE_URL
    }

    companion object {
        val Factory: ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>, extras: androidx.lifecycle.viewmodel.CreationExtras): T {
                val app = checkNotNull(extras[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY])
                return MainViewModel(app) as T
            }
        }
    }
}
