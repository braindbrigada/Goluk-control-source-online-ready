package com.stepmat.golukcontrol.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.stepmat.golukcontrol.viewmodel.MainViewModel

@Composable
fun HomeScreen(
    paddingValues: PaddingValues,
    viewModel: MainViewModel,
    onOpenVideos: () -> Unit
) {
    val state by viewModel.overviewState.collectAsState()
    var showFormatDialog by remember { mutableStateOf(false) }

    Column(
        modifier = ScreenColumnPadding(paddingValues)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Goluk Control",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Локальный клиент для Goluk / GoLook T-series. По умолчанию работает с IP регистратора 192.168.62.1.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.secondary
        )

        SectionCard(
            title = "Подключение",
            subtitle = "Проверьте адрес регистратора и обновите данные"
        ) {
            OutlinedTextField(
                value = state.baseUrl,
                onValueChange = viewModel::updateBaseUrl,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Base URL") },
                singleLine = true
            )

            StatusChip(
                label = when (state.isConnected) {
                    true -> "Регистратор доступен"
                    false -> "Нет соединения"
                    null -> "Статус не проверен"
                },
                positive = state.isConnected
            )

            PresetChipRow(
                labels = listOf(
                    "Сохранить адрес" to { viewModel.persistBaseUrl() },
                    "Проверить связь" to { viewModel.checkConnection() },
                    "Открыть видео" to onOpenVideos
                )
            )

            if (state.isCheckingConnection || state.isLoadingInfo) {
                CircularProgressIndicator(modifier = Modifier.height(24.dp))
            }

            if (!state.message.isNullOrBlank()) {
                Text(text = state.message.orEmpty(), style = MaterialTheme.typography.bodySmall)
            }
        }

        SectionCard(
            title = "Устройство",
            subtitle = "Ответ /api/systeminfo"
        ) {
            Button(onClick = { viewModel.refreshOverview() }) {
                Icon(Icons.Outlined.Refresh, contentDescription = null)
                Text("  Обновить")
            }
            KeyValueList(data = state.systemInfo?.data.orEmpty())
        }

        SectionCard(
            title = "SD-карта",
            subtitle = "Ответ /api/sd"
        ) {
            Button(onClick = { viewModel.refreshOverview() }) {
                Icon(Icons.Outlined.Refresh, contentDescription = null)
                Text("  Обновить статус")
            }

            TextButton(onClick = { showFormatDialog = true }) {
                Icon(Icons.Outlined.DeleteSweep, contentDescription = null)
                Text("  Форматировать SD-карту")
            }

            KeyValueList(data = state.sdInfo?.data.orEmpty())
        }

        SectionCard(
            title = "Быстрые действия",
            subtitle = "Переход к архиву роликов"
        ) {
            Button(onClick = onOpenVideos) {
                Icon(Icons.Outlined.VideoLibrary, contentDescription = null)
                Text("  Открыть список видео")
            }
        }
    }

    if (showFormatDialog) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showFormatDialog = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        showFormatDialog = false
                        viewModel.formatSdCard()
                    }
                ) {
                    Text("Форматировать")
                }
            },
            dismissButton = {
                TextButton(onClick = { showFormatDialog = false }) {
                    Text("Отмена")
                }
            },
            title = { Text("Форматирование SD-карты") },
            text = { Text("Все записи на карте памяти будут удалены. Продолжить?") }
        )
    }
}
