package com.stepmat.golukcontrol.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.nio.charset.StandardCharsets

/**
 * Репозиторий для прямой работы с локальным HTTP API регистратора.
 */
class GolukRepository {

    private data class RawHttpResponse(
        val code: Int,
        val contentType: String,
        val bytes: ByteArray
    ) {
        val bodyAsText: String
            get() = bytes.toString(StandardCharsets.UTF_8)
    }

    fun fetchSystemInfo(baseUrl: String): DynamicApiResponse {
        return getDynamicResponse(baseUrl, "/api/systeminfo")
    }

    fun fetchSdStatus(baseUrl: String): DynamicApiResponse {
        return getDynamicResponse(baseUrl, "/api/sd")
    }

    fun formatSdCard(baseUrl: String): DynamicApiResponse {
        return getDynamicResponse(baseUrl, "/api/sdformat")
    }

    fun fetchVideoList(baseUrl: String, type: VideoType, maxCount: Int = 200): List<VideoItem> {
        val response = getDynamicResponse(
            baseUrl = baseUrl,
            path = "/api/videolist",
            queryParams = linkedMapOf(
                "type" to type.apiValue.toString(),
                "maxcount" to maxCount.toString()
            )
        )

        val raw = JSONObject(response.rawBody)
        val data = raw.optJSONObject("data") ?: return emptyList()
        val list = data.optJSONArray("list") ?: JSONArray()
        val result = mutableListOf<VideoItem>()

        for (index in 0 until list.length()) {
            val item = list.optJSONObject(index) ?: continue
            result += VideoItem(
                id = item.optString("id"),
                type = item.optInt("type"),
                resolution = item.optString("resolution"),
                periodSeconds = item.optInt("period"),
                unixTime = item.optLong("time"),
                timestamp = item.optString("timestamp"),
                sizeBytes = item.optLong("size"),
                location = item.optString("location"),
                withSnapshot = item.optInt("withSnapshot") == 1,
                withThumb = item.optInt("withThumb") == 1,
                withGps = item.optInt("withGps") == 1
            )
        }

        return result.sortedByDescending { it.unixTime ?: 0L }
    }

    fun buildVideoUrl(baseUrl: String, videoId: String): String {
        return buildUrl(baseUrl, "/api/video", linkedMapOf("id" to videoId))
    }

    fun buildSnapshotUrl(baseUrl: String): String {
        return buildUrl(baseUrl, "/api/snapshot", linkedMapOf("id" to "0"))
    }

    fun executeCommand(
        baseUrl: String,
        path: String,
        rawQuery: String
    ): CommandResult {
        val params = parseRawQuery(rawQuery)
        val url = buildUrl(baseUrl, path, params)
        return try {
            val response = executeRawGet(url)
            if (response.code !in 200..299) {
                error("HTTP ${response.code}: ${response.bodyAsText}")
            }

            val isText = response.contentType.contains("json", ignoreCase = true) ||
                response.contentType.startsWith("text/", ignoreCase = true) ||
                response.contentType.isBlank()

            if (!isText) {
                CommandResult(
                    endpoint = path,
                    requestUrl = url,
                    success = true,
                    message = "Получен бинарный ответ (${response.contentType.ifBlank { "unknown" }})",
                    rawBody = "Binary response: ${response.contentType.ifBlank { "unknown" }}, ${response.bytes.size} bytes"
                )
            } else {
                val rawBody = response.bodyAsText
                val json = runCatching { JSONObject(rawBody) }.getOrNull()
                CommandResult(
                    endpoint = path,
                    requestUrl = url,
                    success = json?.optInt("result", 0) == 0 || rawBody.isNotBlank(),
                    message = json?.optString("msg", "OK") ?: "OK",
                    rawBody = rawBody
                )
            }
        } catch (t: Throwable) {
            CommandResult(
                endpoint = path,
                requestUrl = url,
                success = false,
                message = t.message ?: "Не удалось выполнить запрос",
                rawBody = ""
            )
        }
    }

    fun checkConnection(baseUrl: String): Boolean {
        return try {
            val connection = openConnection(buildUrl(baseUrl, "/api/systeminfo"))
            connection.connectTimeout = 2500
            connection.readTimeout = 2500
            connection.requestMethod = "GET"
            connection.connect()
            connection.responseCode in 200..299
        } catch (_: Throwable) {
            false
        }
    }

    private fun getDynamicResponse(
        baseUrl: String,
        path: String,
        queryParams: Map<String, String> = emptyMap()
    ): DynamicApiResponse {
        val url = buildUrl(baseUrl, path, queryParams)
        val rawBody = executeGet(url)
        val root = JSONObject(rawBody)
        val data = root.optJSONObject("data")?.toMap().orEmpty()
        return DynamicApiResponse(
            result = root.optInt("result"),
            msg = root.optString("msg"),
            data = data,
            rawBody = rawBody
        )
    }

    private fun buildUrl(baseUrl: String, path: String, params: Map<String, String> = emptyMap()): String {
        val normalizedBase = baseUrl.trim().trimEnd('/')
        val normalizedPath = if (path.startsWith('/')) path else "/$path"
        if (params.isEmpty()) {
            return normalizedBase + normalizedPath
        }
        val query = params.entries.joinToString("&") { (key, value) ->
            val encodedKey = URLEncoder.encode(key, StandardCharsets.UTF_8.toString())
            val encodedValue = URLEncoder.encode(value, StandardCharsets.UTF_8.toString())
            "$encodedKey=$encodedValue"
        }
        return "${normalizedBase}${normalizedPath}?$query"
    }

    private fun parseRawQuery(rawQuery: String): Map<String, String> {
        if (rawQuery.isBlank()) return emptyMap()
        return rawQuery.split('&')
            .mapNotNull { part ->
                val pieces = part.split('=', limit = 2)
                if (pieces.isEmpty() || pieces.first().isBlank()) return@mapNotNull null
                val key = pieces[0].trim()
                val value = pieces.getOrNull(1)?.trim().orEmpty()
                key to value
            }
            .toMap(linkedMapOf())
    }

    private fun executeGet(urlString: String): String {
        val response = executeRawGet(urlString)
        val body = response.bodyAsText
        if (response.code !in 200..299) {
            error("HTTP ${response.code}: $body")
        }
        return body
    }

    private fun executeRawGet(urlString: String): RawHttpResponse {
        val connection = openConnection(urlString)
        connection.requestMethod = "GET"
        connection.connectTimeout = 5000
        connection.readTimeout = 15000
        connection.connect()

        val code = connection.responseCode
        val contentType = connection.contentType.orEmpty()
        val stream = if (code in 200..299) {
            connection.inputStream
        } else {
            connection.errorStream ?: connection.inputStream
        }

        val bytes = stream.use(::readToBytes)
        return RawHttpResponse(code = code, contentType = contentType, bytes = bytes)
    }

    private fun openConnection(urlString: String): HttpURLConnection {
        return (URL(urlString).openConnection() as HttpURLConnection).apply {
            setRequestProperty("Accept", "application/json, text/plain, */*")
            setRequestProperty("Connection", "close")
            doInput = true
            useCaches = false
        }
    }

    private fun readToBytes(inputStream: InputStream): ByteArray {
        val output = ByteArrayOutputStream()
        BufferedInputStream(inputStream).use { input ->
            val buffer = ByteArray(8 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                output.write(buffer, 0, read)
            }
        }
        return output.toByteArray()
    }
}

private fun JSONObject.toMap(): Map<String, Any?> {
    val result = linkedMapOf<String, Any?>()
    val iterator = keys()
    while (iterator.hasNext()) {
        val key = iterator.next()
        result[key] = get(key).toKotlinValue()
    }
    return result
}

private fun JSONArray.toList(): List<Any?> {
    val list = mutableListOf<Any?>()
    for (index in 0 until length()) {
        list += get(index).toKotlinValue()
    }
    return list
}

private fun Any?.toKotlinValue(): Any? {
    return when (this) {
        is JSONObject -> this.toMap()
        is JSONArray -> this.toList()
        JSONObject.NULL -> null
        else -> this
    }
}
