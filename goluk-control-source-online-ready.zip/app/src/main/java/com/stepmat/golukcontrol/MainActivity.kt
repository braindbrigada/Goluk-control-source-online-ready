package com.stepmat.golukcontrol

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.List
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.SettingsEthernet
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.stepmat.golukcontrol.ui.screens.ApiScreen
import com.stepmat.golukcontrol.ui.screens.HomeScreen
import com.stepmat.golukcontrol.ui.screens.PlayerScreen
import com.stepmat.golukcontrol.ui.screens.VideosScreen
import com.stepmat.golukcontrol.ui.theme.GolukControlTheme
import com.stepmat.golukcontrol.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GolukControlTheme {
                GolukApp()
            }
        }
    }
}

private data class BottomDestination(
    val route: String,
    val label: String,
    val icon: @Composable () -> Unit
)

@Composable
private fun GolukApp(viewModel: MainViewModel = viewModel(factory = MainViewModel.Factory)) {
    val navController = rememberNavController()
    val items = listOf(
        BottomDestination("home", "Обзор") { Icon(Icons.Outlined.Home, contentDescription = null) },
        BottomDestination("videos", "Видео") { Icon(Icons.Outlined.List, contentDescription = null) },
        BottomDestination("api", "Настройки / API") { Icon(Icons.Outlined.SettingsEthernet, contentDescription = null) }
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = navBackStackEntry?.destination
            NavigationBar {
                items.forEach { item ->
                    NavigationBarItem(
                        selected = currentDestination?.hierarchy?.any { it.route == item.route } == true,
                        onClick = {
                            navController.navigate(item.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = item.icon,
                        label = { Text(item.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.fillMaxSize()
        ) {
            composable("home") {
                HomeScreen(
                    paddingValues = innerPadding,
                    viewModel = viewModel,
                    onOpenVideos = {
                        navController.navigate("videos")
                    }
                )
            }
            composable("videos") {
                VideosScreen(
                    paddingValues = innerPadding,
                    viewModel = viewModel,
                    onPlayVideo = { videoId ->
                        navController.navigate("player/$videoId")
                    }
                )
            }
            composable("api") {
                ApiScreen(
                    paddingValues = innerPadding,
                    viewModel = viewModel
                )
            }
            composable("player/{videoId}") { backStackEntry ->
                val videoId = backStackEntry.arguments?.getString("videoId").orEmpty()
                PlayerScreen(
                    paddingValues = innerPadding,
                    viewModel = viewModel,
                    videoId = videoId,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
