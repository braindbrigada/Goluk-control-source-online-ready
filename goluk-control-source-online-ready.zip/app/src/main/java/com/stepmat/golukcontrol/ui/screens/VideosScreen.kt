package com.stepmat.golukcontrol.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.PlayCircleOutline
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.stepmat.golukcontrol.data.VideoItem
import com.stepmat.golukcontrol.data.VideoType
import com.stepmat.golukcontrol.util.formatBytes
import com.stepmat.golukcontrol.util.formatDuration
import com.stepmat.golukcontrol.util.formatUnixTime
import com.stepmat.golukcontrol.viewmodel.MainViewModel

@Composable
fun VideosScreen(
    paddingValues: PaddingValues,
    viewModel: MainViewModel,
    onPlayVideo: (String) -> Unit
) {
    val state by viewModel.videosState.collectAsState()

    Column(
        modifier = ScreenColumnPadding(paddingValues),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Архив видео",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        SectionCard(
            title = "Фильтр",
            subtitle = "Список загружается через /api/videolist"
        ) {
            PresetChipRow(
                labels = VideoType.entries.map { type ->
                    val label = if (type == state.selectedType) "✓ ${type.title}" else type.title
                    label to { viewModel.loadVideos(type) }
                }
            )
            AssistChip(
                onClick = { viewModel.loadVideos(state.selectedType) },
                label = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Refresh, contentDescription = null)
                        Text("  Обновить")
                    }
                }
            )
            if (state.isLoading) {
                CircularProgressIndicator()
            }
            if (!state.error.isNullOrBlank()) {
                Text(text = state.error.orEmpty(), color = MaterialTheme.colorScheme.error)
            }
            Text(
                text = "Найдено роликов: ${state.items.size}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.secondary
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(state.items, key = { it.id }) { item ->
                VideoItemCard(item = item, onPlay = { onPlayVideo(item.id) })
            }
        }
    }
}

@Composable
private fun VideoItemCard(
    item: VideoItem,
    onPlay: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onPlay)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(text = item.id, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(
                        text = "${item.resolution ?: "—"} · ${formatDuration(item.periodSeconds)} · ${formatBytes(item.sizeBytes)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.PlayCircleOutline, contentDescription = null)
                    Text("  Открыть")
                }
            }

            Text(
                text = "Дата: ${formatUnixTime(item.unixTime)}",
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = "Файл: ${item.location ?: "—"}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.secondary
            )
        }
    }
}
